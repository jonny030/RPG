/********************************************************************************
** Form generated from reading UI file 'container.ui'
**
** Created by: Qt User Interface Compiler version 5.12.11
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_CONTAINER_H
#define UI_CONTAINER_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QToolBox>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Dialog_container
{
public:
    QGroupBox *groupBox;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QToolBox *toolBox;
    QWidget *page;
    QWidget *widget1;
    QVBoxLayout *verticalLayout_3;
    QRadioButton *radioButton_5;
    QRadioButton *radioButton_6;
    QRadioButton *radioButton_4;
    QWidget *page_2;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_4;
    QRadioButton *radioButton_7;
    QRadioButton *radioButton_8;
    QRadioButton *radioButton_9;
    QToolBox *toolBox_2;
    QWidget *page_3;
    QWidget *layoutWidget_2;
    QVBoxLayout *verticalLayout_5;
    QRadioButton *radioButton_10;
    QRadioButton *radioButton_11;
    QRadioButton *radioButton_12;
    QWidget *page_4;
    QWidget *layoutWidget_3;
    QVBoxLayout *verticalLayout_6;
    QRadioButton *radioButton_13;
    QRadioButton *radioButton_14;
    QRadioButton *radioButton_15;
    QTabWidget *tabWidget;
    QWidget *tab;
    QWidget *layoutWidget_4;
    QVBoxLayout *verticalLayout_7;
    QRadioButton *radioButton_16;
    QRadioButton *radioButton_17;
    QRadioButton *radioButton_18;
    QWidget *tab_2;
    QWidget *layoutWidget_5;
    QVBoxLayout *verticalLayout_8;
    QRadioButton *radioButton_19;
    QRadioButton *radioButton_20;
    QRadioButton *radioButton_21;
    QFrame *frame;

    void setupUi(QDialog *Dialog)
    {
        if (Dialog->objectName().isEmpty())
            Dialog->setObjectName(QString::fromUtf8("Dialog"));
        Dialog->resize(605, 333);
        groupBox = new QGroupBox(Dialog);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setGeometry(QRect(10, 20, 151, 111));
        widget = new QWidget(groupBox);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(10, 20, 111, 73));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        radioButton = new QRadioButton(widget);
        radioButton->setObjectName(QString::fromUtf8("radioButton"));

        verticalLayout_2->addWidget(radioButton);

        radioButton_2 = new QRadioButton(widget);
        radioButton_2->setObjectName(QString::fromUtf8("radioButton_2"));

        verticalLayout_2->addWidget(radioButton_2);

        radioButton_3 = new QRadioButton(widget);
        radioButton_3->setObjectName(QString::fromUtf8("radioButton_3"));

        verticalLayout_2->addWidget(radioButton_3);

        toolBox = new QToolBox(Dialog);
        toolBox->setObjectName(QString::fromUtf8("toolBox"));
        toolBox->setGeometry(QRect(20, 160, 131, 141));
        page = new QWidget();
        page->setObjectName(QString::fromUtf8("page"));
        page->setGeometry(QRect(0, 0, 131, 81));
        widget1 = new QWidget(page);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(10, 0, 111, 73));
        verticalLayout_3 = new QVBoxLayout(widget1);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        radioButton_5 = new QRadioButton(widget1);
        radioButton_5->setObjectName(QString::fromUtf8("radioButton_5"));

        verticalLayout_3->addWidget(radioButton_5);

        radioButton_6 = new QRadioButton(widget1);
        radioButton_6->setObjectName(QString::fromUtf8("radioButton_6"));

        verticalLayout_3->addWidget(radioButton_6);

        radioButton_4 = new QRadioButton(widget1);
        radioButton_4->setObjectName(QString::fromUtf8("radioButton_4"));

        verticalLayout_3->addWidget(radioButton_4);

        toolBox->addItem(page, QString::fromUtf8("\345\234\213\345\205\247"));
        page_2 = new QWidget();
        page_2->setObjectName(QString::fromUtf8("page_2"));
        page_2->setGeometry(QRect(0, 0, 131, 81));
        layoutWidget = new QWidget(page_2);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(10, 0, 111, 73));
        verticalLayout_4 = new QVBoxLayout(layoutWidget);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        verticalLayout_4->setContentsMargins(0, 0, 0, 0);
        radioButton_7 = new QRadioButton(layoutWidget);
        radioButton_7->setObjectName(QString::fromUtf8("radioButton_7"));

        verticalLayout_4->addWidget(radioButton_7);

        radioButton_8 = new QRadioButton(layoutWidget);
        radioButton_8->setObjectName(QString::fromUtf8("radioButton_8"));

        verticalLayout_4->addWidget(radioButton_8);

        radioButton_9 = new QRadioButton(layoutWidget);
        radioButton_9->setObjectName(QString::fromUtf8("radioButton_9"));

        verticalLayout_4->addWidget(radioButton_9);

        toolBox->addItem(page_2, QString::fromUtf8("\345\234\213\345\244\226"));
        toolBox_2 = new QToolBox(Dialog);
        toolBox_2->setObjectName(QString::fromUtf8("toolBox_2"));
        toolBox_2->setGeometry(QRect(190, 160, 131, 141));
        page_3 = new QWidget();
        page_3->setObjectName(QString::fromUtf8("page_3"));
        page_3->setGeometry(QRect(0, 0, 131, 81));
        layoutWidget_2 = new QWidget(page_3);
        layoutWidget_2->setObjectName(QString::fromUtf8("layoutWidget_2"));
        layoutWidget_2->setGeometry(QRect(10, 0, 111, 73));
        verticalLayout_5 = new QVBoxLayout(layoutWidget_2);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        radioButton_10 = new QRadioButton(layoutWidget_2);
        radioButton_10->setObjectName(QString::fromUtf8("radioButton_10"));

        verticalLayout_5->addWidget(radioButton_10);

        radioButton_11 = new QRadioButton(layoutWidget_2);
        radioButton_11->setObjectName(QString::fromUtf8("radioButton_11"));

        verticalLayout_5->addWidget(radioButton_11);

        radioButton_12 = new QRadioButton(layoutWidget_2);
        radioButton_12->setObjectName(QString::fromUtf8("radioButton_12"));

        verticalLayout_5->addWidget(radioButton_12);

        toolBox_2->addItem(page_3, QString::fromUtf8("\345\234\213\345\205\247"));
        page_4 = new QWidget();
        page_4->setObjectName(QString::fromUtf8("page_4"));
        page_4->setGeometry(QRect(0, 0, 131, 81));
        layoutWidget_3 = new QWidget(page_4);
        layoutWidget_3->setObjectName(QString::fromUtf8("layoutWidget_3"));
        layoutWidget_3->setGeometry(QRect(10, 0, 111, 73));
        verticalLayout_6 = new QVBoxLayout(layoutWidget_3);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        radioButton_13 = new QRadioButton(layoutWidget_3);
        radioButton_13->setObjectName(QString::fromUtf8("radioButton_13"));

        verticalLayout_6->addWidget(radioButton_13);

        radioButton_14 = new QRadioButton(layoutWidget_3);
        radioButton_14->setObjectName(QString::fromUtf8("radioButton_14"));

        verticalLayout_6->addWidget(radioButton_14);

        radioButton_15 = new QRadioButton(layoutWidget_3);
        radioButton_15->setObjectName(QString::fromUtf8("radioButton_15"));

        verticalLayout_6->addWidget(radioButton_15);

        toolBox_2->addItem(page_4, QString::fromUtf8("\345\234\213\345\244\226"));
        tabWidget = new QTabWidget(Dialog);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(180, 10, 181, 121));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        layoutWidget_4 = new QWidget(tab);
        layoutWidget_4->setObjectName(QString::fromUtf8("layoutWidget_4"));
        layoutWidget_4->setGeometry(QRect(10, 10, 111, 73));
        verticalLayout_7 = new QVBoxLayout(layoutWidget_4);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        verticalLayout_7->setContentsMargins(0, 0, 0, 0);
        radioButton_16 = new QRadioButton(layoutWidget_4);
        radioButton_16->setObjectName(QString::fromUtf8("radioButton_16"));

        verticalLayout_7->addWidget(radioButton_16);

        radioButton_17 = new QRadioButton(layoutWidget_4);
        radioButton_17->setObjectName(QString::fromUtf8("radioButton_17"));

        verticalLayout_7->addWidget(radioButton_17);

        radioButton_18 = new QRadioButton(layoutWidget_4);
        radioButton_18->setObjectName(QString::fromUtf8("radioButton_18"));

        verticalLayout_7->addWidget(radioButton_18);

        tabWidget->addTab(tab, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        layoutWidget_5 = new QWidget(tab_2);
        layoutWidget_5->setObjectName(QString::fromUtf8("layoutWidget_5"));
        layoutWidget_5->setGeometry(QRect(10, 10, 111, 73));
        verticalLayout_8 = new QVBoxLayout(layoutWidget_5);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        verticalLayout_8->setContentsMargins(0, 0, 0, 0);
        radioButton_19 = new QRadioButton(layoutWidget_5);
        radioButton_19->setObjectName(QString::fromUtf8("radioButton_19"));

        verticalLayout_8->addWidget(radioButton_19);

        radioButton_20 = new QRadioButton(layoutWidget_5);
        radioButton_20->setObjectName(QString::fromUtf8("radioButton_20"));

        verticalLayout_8->addWidget(radioButton_20);

        radioButton_21 = new QRadioButton(layoutWidget_5);
        radioButton_21->setObjectName(QString::fromUtf8("radioButton_21"));

        verticalLayout_8->addWidget(radioButton_21);

        tabWidget->addTab(tab_2, QString());
        frame = new QFrame(Dialog);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(390, 20, 171, 111));
        frame->setAutoFillBackground(true);
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);

        retranslateUi(Dialog);

        toolBox->setCurrentIndex(0);
        toolBox_2->setCurrentIndex(1);
        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(Dialog);
    } // setupUi

    void retranslateUi(QDialog *Dialog)
    {
        Dialog->setWindowTitle(QApplication::translate("Dialog", "Dialog", nullptr));
        groupBox->setTitle(QApplication::translate("Dialog", "\345\245\227\350\243\235\350\241\214\347\250\213", nullptr));
        radioButton->setText(QApplication::translate("Dialog", "\350\212\261\346\235\2615\346\227\245\351\201\212", nullptr));
        radioButton_2->setText(QApplication::translate("Dialog", "\345\242\276\344\270\2013\346\227\245\351\201\212", nullptr));
        radioButton_3->setText(QApplication::translate("Dialog", "\344\270\255\345\217\260\347\201\2433\346\227\245\351\201\212", nullptr));
        radioButton_5->setText(QApplication::translate("Dialog", "\350\212\261\346\235\2615\346\227\245\351\201\212", nullptr));
        radioButton_6->setText(QApplication::translate("Dialog", "\345\242\276\344\270\2013\346\227\245\351\201\212", nullptr));
        radioButton_4->setText(QApplication::translate("Dialog", "\344\270\255\345\217\260\347\201\2433\346\227\245\351\201\212", nullptr));
        toolBox->setItemText(toolBox->indexOf(page), QApplication::translate("Dialog", "\345\234\213\345\205\247", nullptr));
        radioButton_7->setText(QApplication::translate("Dialog", "\346\227\245\346\234\2545\346\227\245\351\201\212", nullptr));
        radioButton_8->setText(QApplication::translate("Dialog", "\351\237\223\345\234\2134\346\227\245\351\201\212", nullptr));
        radioButton_9->setText(QApplication::translate("Dialog", "\346\263\260\345\234\2133\346\227\245\351\201\212", nullptr));
        toolBox->setItemText(toolBox->indexOf(page_2), QApplication::translate("Dialog", "\345\234\213\345\244\226", nullptr));
        radioButton_10->setText(QApplication::translate("Dialog", "\350\212\261\346\235\2615\346\227\245\351\201\212", nullptr));
        radioButton_11->setText(QApplication::translate("Dialog", "\345\242\276\344\270\2013\346\227\245\351\201\212", nullptr));
        radioButton_12->setText(QApplication::translate("Dialog", "\344\270\255\345\217\260\347\201\2433\346\227\245\351\201\212", nullptr));
        toolBox_2->setItemText(toolBox_2->indexOf(page_3), QApplication::translate("Dialog", "\345\234\213\345\205\247", nullptr));
        radioButton_13->setText(QApplication::translate("Dialog", "\346\227\245\346\234\2545\346\227\245\351\201\212", nullptr));
        radioButton_14->setText(QApplication::translate("Dialog", "\351\237\223\345\234\2134\346\227\245\351\201\212", nullptr));
        radioButton_15->setText(QApplication::translate("Dialog", "\346\263\260\345\234\2133\346\227\245\351\201\212", nullptr));
        toolBox_2->setItemText(toolBox_2->indexOf(page_4), QApplication::translate("Dialog", "\345\234\213\345\244\226", nullptr));
        radioButton_16->setText(QApplication::translate("Dialog", "\350\212\261\346\235\2615\346\227\245\351\201\212", nullptr));
        radioButton_17->setText(QApplication::translate("Dialog", "\345\242\276\344\270\2013\346\227\245\351\201\212", nullptr));
        radioButton_18->setText(QApplication::translate("Dialog", "\344\270\255\345\217\260\347\201\2433\346\227\245\351\201\212", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("Dialog", "\345\234\213\345\205\247", nullptr));
        radioButton_19->setText(QApplication::translate("Dialog", "\346\227\245\346\234\2545\346\227\245\351\201\212", nullptr));
        radioButton_20->setText(QApplication::translate("Dialog", "\351\237\223\345\234\2134\346\227\245\351\201\212", nullptr));
        radioButton_21->setText(QApplication::translate("Dialog", "\346\263\260\345\234\2133\346\227\245\351\201\212", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("Dialog", "\345\234\213\345\244\226", nullptr));
    } // retranslateUi

};

namespace Uc {
    class Dialog_container: public Ui_Dialog_container {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_CONTAINER_H
