﻿#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

QT_BEGIN_NAMESPACE
namespace Ui { class Dialog; }
namespace Ua { class Dialog_input; }
namespace Ub { class Dialog_calender; }
namespace Uc { class Dialog_container; }
QT_END_NAMESPACE

class Dialog : public QDialog
{
    Q_OBJECT

public:
    Dialog(QWidget *parent = nullptr);
    ~Dialog();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::Dialog *ui;
};


class Dialog_input : public QDialog
{
    Q_OBJECT

public:
    Dialog_input(QWidget *parent = nullptr);
    ~Dialog_input();

private:
    Ua::Dialog_input *ua;
};


class Dialog_calender : public QDialog
{
    Q_OBJECT

public:
    Dialog_calender(QWidget *parent = nullptr);
    ~Dialog_calender();

private:
    Ub::Dialog_calender *ub;
};


class Dialog_container : public QDialog
{
    Q_OBJECT

public:
    Dialog_container(QWidget *parent = nullptr);
    ~Dialog_container();

private:
    Uc::Dialog_container *uc;
};
#endif // DIALOG_H
