﻿#include "dialog.h"
#include "ui_dialog.h"
#include "ui_input.h"
#include "ui_calender.h"
#include "ui_container.h"


Dialog_input::Dialog_input(QWidget *parent)
    : QDialog(parent)
    , ua(new Ua::Dialog_input)
{
    ua->setupUi(this);
}

Dialog_input::~Dialog_input()
{
    delete ua;
}


Dialog_calender::Dialog_calender(QWidget *parent)
    : QDialog(parent)
    , ub(new Ub::Dialog_calender)
{
    ub->setupUi(this);
}

Dialog_calender::~Dialog_calender()
{
    delete ub;
}


Dialog_container::Dialog_container(QWidget *parent)
    : QDialog(parent)
    , uc(new Uc::Dialog_container)
{
    uc->setupUi(this);
}

Dialog_container::~Dialog_container()
{
    delete uc;
}


Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
    ui->pushButton->setText(QString("Calender"));
    ui->pushButton_2->setText(QString("Input"));
    ui->pushButton_3->setText(QString("Container"));
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    Dialog_calender a;
    a.show();
    a.exec();
}


void Dialog::on_pushButton_2_clicked()
{
    Dialog_input a;
    a.show();
    a.exec();
}


void Dialog::on_pushButton_3_clicked()
{
    Dialog_container a;
    a.show();
    a.exec();
}
